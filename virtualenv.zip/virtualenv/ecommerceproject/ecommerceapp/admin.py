from django.contrib import admin
from .models import Product,speaker,printer,smartwatch,monitor,appliance,topdeal,decorationitem,fashiondeal,earbud

# Register your models here.
admin.site.register(Product)
admin.site.register(speaker)
admin.site.register(printer)
admin.site.register(smartwatch)
admin.site.register(monitor)
admin.site.register(appliance)
admin.site.register(topdeal)
admin.site.register(decorationitem)
admin.site.register(fashiondeal)
admin.site.register(earbud)